package com.FreelancingFreaks.FreelancingFreaks.repository;

public interface ServiceRepo {

}
