package com.FreelancingFreaks.FreelancingFreaks.services;

import java.util.List;

import com.FreelancingFreaks.FreelancingFreaks.Entity.Contact;


public interface contactService {
	Contact addContact(Contact contact);
	void deleteContact(long con_id);	
	Contact getContactById(long con_id);
	List <Contact> getAllContact();

}
