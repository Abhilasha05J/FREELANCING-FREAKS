package com.FreelancingFreaks.FreelancingFreaks.services;

public interface ServiceService {

}
