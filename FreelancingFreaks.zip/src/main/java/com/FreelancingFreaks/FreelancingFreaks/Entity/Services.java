package com.FreelancingFreaks.FreelancingFreaks.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Services")
public class Services {
    @Id 
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="service_id")
    private long service_id;
    
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category; // Change the type to the Category entity

    @Column(name="service_name")
    private String service_name;

    @Column(name="status")
    private boolean status;
    
    // Other fields and methods...

    // Getter and setter for the category field
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    // Constructors, toString method, and other methods...
}
