package com.FreelancingFreaks.FreelancingFreaks.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.FreelancingFreaks.FreelancingFreaks.Entity.Category;
import com.FreelancingFreaks.FreelancingFreaks.Entity.Contact;
import com.FreelancingFreaks.FreelancingFreaks.Entity.User;
import com.FreelancingFreaks.FreelancingFreaks.repository.contactRepo;
import com.FreelancingFreaks.FreelancingFreaks.repository.userrepo;
import com.FreelancingFreaks.FreelancingFreaks.services.CategoryServiceImp;
import com.FreelancingFreaks.FreelancingFreaks.services.ContactServiceImp;
import com.FreelancingFreaks.FreelancingFreaks.services.userserviceimp;

import jakarta.servlet.http.HttpSession;

@Controller
public class RouterClass {
	@Autowired
	private userrepo userrepo1;
	@Autowired
	private contactRepo contactRepo1;
	@Autowired
	private userserviceimp service;
	@Autowired
	private ContactServiceImp contactS;
	@Autowired
	private CategoryServiceImp cat;
	
	//index
	@GetMapping("/")
	public String index(Model model)
	{
		model.addAttribute("contact", new Contact());
		return "index.html";
	}
	
	
	
	//login signup
	@GetMapping("/login")
	public String Login()
	{
		return "Login.html";
	}
	@GetMapping("/signup")
	public String signup(Model model)
	{
		model.addAttribute("user", new User());
		return "Signup.html";
	}
	
	//user
	@PostMapping("/addUSer")
	public String processForm(User user, Model model)
	{
		userrepo1.save(user);
		System.out.println(user.getEmail());
		return "redirect:/signup";
	}
	@GetMapping("/user")
	public String client(Model model)
	{
		List<User>user=service.getAllUser();
		model.addAttribute("user",user);
		return "userlist.html";
	}
	@GetMapping("/user/{id}")
	public String deleteuser(@PathVariable long id,HttpSession session)
	{
		service.deleteUser(id);
		return "redirect:/userlist";
	}
	
	
	//admin
		@GetMapping("/admin")
		public String admin()
		{
			return "AdminDashboard.html";
		}
		@GetMapping("/category")
		public String category(Model model)
		{
			List<Category>category=cat.getAllCategory();
			model.addAttribute("category",cat);
			return "category.html";
		}
		@GetMapping("/service")
		public String service()
		{
			return "services.html";
		}
		
		
//		Contact
		@GetMapping("/contact")
		public String contact(Model model)
		{
			List<Contact>contact=contactS.getAllContact();
			model.addAttribute("contact",contact);
			return "contact.html";
		}
		@PostMapping("/addContact")
		public String processContactForm(Contact contact, Model model)
		{
			contactRepo1.save(contact);
			System.out.println(contact.getEmail());
			return "/";
		}
		@GetMapping("/deletecontact/{con_id}")
		public String deleteContact(@PathVariable long con_id,HttpSession session)
		{
			contactS.deleteContact(con_id);
			return "redirect:/contact";
		}
		
		
		//client
		@GetMapping("/client")
		public String client()
		{
			return "Client.html";
		}

		
		
}
